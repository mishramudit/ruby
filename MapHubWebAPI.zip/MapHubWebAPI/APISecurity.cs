﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MapHubWebAPI.Models;

namespace MapHubWebAPI
{
    public class APISecurity
    {
        public static bool Login(string username, string password)
        {
            using (UserDataContext db = new UserDataContext())
            {
                return db.UserDatas.Any(user => user.UserName.Equals(username, StringComparison.OrdinalIgnoreCase) && user.Password.Equals(password));
            }
        }
    }
}