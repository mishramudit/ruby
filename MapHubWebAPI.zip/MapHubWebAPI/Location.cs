﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MapHubWebAPI
{
    public class Location
    {
        public double latitude { get; set; }
        public double longitude { get; set; }
    }
}