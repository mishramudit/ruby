﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Microsoft.AspNet.SignalR;
using MapHubWebAPI.Hubs;
using System.Threading;

namespace MapHubWebAPI.Controllers
{
    [RoutePrefix("api/map")]
    public class MapController : ApiController
    {
        /// <summary>
        /// This API call will Post latitide and longitude to server
        /// </summary>
        /// <param name="loc"></param>
        /// <returns></returns>
        [Route("location",Name = "SendLocation")]
        [BasicAuthentication]
        public HttpResponseMessage Post([FromBody] Location loc)
        {
            string username = Thread.CurrentPrincipal.Identity.Name;

            var mappingHub = GlobalHost.ConnectionManager.GetHubContext<MapHub>();

            mappingHub.Clients.All.broadcastMessage(loc.latitude, loc.longitude);

            var message = Request.CreateResponse(HttpStatusCode.Created, loc);

            string uri = Url.Link("SendLocation", new { Latitide=loc.latitude,Longitude=loc.longitude });

            message.Headers.Location = new Uri(uri);

            return message;
        }
    }
}
